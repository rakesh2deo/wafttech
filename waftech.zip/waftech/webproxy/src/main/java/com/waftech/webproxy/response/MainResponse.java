package com.waftech.webproxy.response;

public class MainResponse {

    public  GetResponse getResponse;

    public  PostResponse postResponse;

    public  MainResponse(){

    }

    public GetResponse getGetResponse() {
        return getResponse;
    }

    public void setGetResponse(GetResponse getResponse) {
        this.getResponse = getResponse;
    }

    public PostResponse getPostResponse() {
        return postResponse;
    }

    public void setPostResponse(PostResponse postResponse) {
        this.postResponse = postResponse;
    }



}
