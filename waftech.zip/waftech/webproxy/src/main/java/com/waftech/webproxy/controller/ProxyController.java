package com.waftech.webproxy.controller;

import java.io.File;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.waftech.webproxy.response.*;

@RestController
@RequestMapping("/")
public class ProxyController {
    private static final String FILE_BASE_PATH = System.getProperty("java.io.tmpdir");
    private RestTemplate template;
    private List<String> upstreamServer = new ArrayList<>();
    private final AtomicInteger upstreamIndex = new AtomicInteger(0);
    private final ExecutorService executorService = Executors.newFixedThreadPool(3);
    private List<Long> GET_CALLS = Collections.synchronizedList(new ArrayList<>());
    private List<Long> POST_CALLS = Collections.synchronizedList(new ArrayList<>());

    @Autowired
    public ProxyController(final RestTemplate template, final Environment environment){
        this.template = template;
        Collections.addAll(upstreamServer, environment.getProperty("upstreams").split(","));
    }

    @RequestMapping(value = "/metrics", method = RequestMethod.GET)
    public ResponseEntity<MainResponse> metrics(){
        int totalGetRequest = GET_CALLS.size();
        long maxCallTime = GET_CALLS.stream().max(Long::compareTo).get();
        long minCallTime = GET_CALLS.stream().min(Long::compareTo).get();
        double avgCallTime = GET_CALLS.stream().mapToDouble(a -> a).average().getAsDouble();

        int totalRequestPost = POST_CALLS.size();
        long maxCallTimePost = POST_CALLS.stream().max(Long::compareTo).get();
        long minCallTimePost = POST_CALLS.stream().min(Long::compareTo).get();
        double avgCallTimePost = POST_CALLS.stream().mapToDouble(a -> a).average().getAsDouble();

        GetResponse r1=new GetResponse();
        r1.setMinCallTime(minCallTime);
        r1.setMaxCallTime(maxCallTime);
        r1.setAvgCallTime(avgCallTime);
        r1.setTotalGetRequest(totalGetRequest);


        PostResponse r2=new PostResponse();
        r2.setMinCallTimePost(minCallTimePost);
        r2.setMaxCallTimePost(maxCallTimePost);
        r2.setAvgCallTimePost(avgCallTimePost);
        r2.setTotalRequestPost(totalRequestPost);

        MainResponse mainResponse=new MainResponse();
        mainResponse.setGetResponse(r1);
        mainResponse.setPostResponse(r2);

      return new ResponseEntity<MainResponse>(mainResponse, HttpStatus.OK);

    }

    @RequestMapping(value = "/**", method = RequestMethod.GET)
    public ResponseEntity<Resource> getProxy(HttpServletRequest req) {
        int index = upstreamIndex.getAndIncrement();
        if (index == upstreamServer.size()) {
            index = 0;
            upstreamIndex.set(0);
        }
        String url = upstreamServer.get(index);
        String serverPath = req.getServletPath();
        url += serverPath;
        String queryPath = req.getQueryString();
        if (null != queryPath) {
            url += "?" + queryPath;
        }
        HttpHeaders headers = new HttpHeaders();
        Enumeration<String> headerNames = req.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String header = headerNames.nextElement();
            headers.add(header, req.getHeader(header));
        }
        HttpEntity<String> entity = new HttpEntity<>(headers);
        long tick = System.currentTimeMillis();
        ResponseEntity<Resource> result = template.exchange(url, HttpMethod.GET, entity, Resource.class);
        long tock = System.currentTimeMillis();
        GET_CALLS.add(tock-tick);
        return result;
    }
    @SuppressWarnings("unused")
    @RequestMapping(value = "/**", method = RequestMethod.POST)
    public ResponseEntity<Resource> postProxy(HttpServletRequest req) {
        ByteArrayOutputStream bodyData = null;
        int count = 0;
        try {
            InputStream br = req.getInputStream();
            bodyData = new ByteArrayOutputStream();
            bodyData.write(br);
            byte[] payload = bodyData.toByteArray();
            MultiValueMap<String, Object> params = null;
            if (null != payload && payload.length > 0) { // && payload.length > 0
                System.out.println("Body : " + new String(payload));
            } else {
                Enumeration<String> paramKeys = req.getParameterNames();
                params = new LinkedMultiValueMap<>();
                while (paramKeys.hasMoreElements()) {
                    String paramName = paramKeys.nextElement();
                    params.add(paramName, req.getParameter(paramName));
                }
                for (Part part : req.getParts()) {
                    if(null == part || null == part.getSubmittedFileName()){
                        continue;
                    }
                    System.out.println(part.getSubmittedFileName());
                    File file = new File(FILE_BASE_PATH, part.getSubmittedFileName());
                    part.write(file.getPath());
                    params.add(part.getName(), new FileSystemResource(file));
                    part.delete();
                }
            }
            Enumeration<String> headerNames = req.getHeaderNames();
            HttpHeaders headers = new HttpHeaders();
            while (headerNames.hasMoreElements()) {
                String header = headerNames.nextElement();
                headers.add(header, req.getHeader(header));
            }
            String serverPath = req.getServletPath();
            String queryPath = req.getQueryString();
            HttpEntity<Object> entity;
            List<CompletableFuture<ResponseEntity<Resource>>> tasks = new ArrayList<>(upstreamServer.size());
            for (String upstream : upstreamServer) {
                upstream += serverPath;
                if (null != queryPath) {
                    upstream += "?" + queryPath;
                }
                if (null != payload && payload.length > 0) {
                    entity = new HttpEntity<>(payload, headers);
                } else {
                    entity = new HttpEntity<>(params, headers);
                }
                CompletableFuture<ResponseEntity<Resource>> completableFuture = CompletableFuture
                        .supplyAsync(new ProxyWorker(template, entity, upstream), executorService);
                tasks.add(completableFuture);
            }
            if(tasks.size() > 0) {
                long tick = System.currentTimeMillis();
                List<ResponseEntity<Resource>> results = tasks.stream()
                        .map(CompletableFuture::join)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList());
                long tock = System.currentTimeMillis();
                POST_CALLS.add(tock-tick);
                if(results.size() != upstreamServer.size()){
                    return null;
                }else{
                    return results.get(0);
                }
            }else{
                System.out.println("No upstream url found.");
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
